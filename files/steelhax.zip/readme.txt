The steelhax folder goes onto the SD card
Make sure to download the otherapp payload for your firmware and save it in the steelhax folder as payload.bin
The save file just goes straight into the savegame